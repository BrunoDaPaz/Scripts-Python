def main():
    lista1 = [1,2,3,4]
    lista2 = ['python', 'Java', 'C#']
    lista3 = [10, 'valor', 3.14]

    print(lista1)
    print(lista2)
    print(lista3)

    print(lista3[2])
    lista = list('Franciela')
    print(lista)

if __name__ == "__main__":
    main()